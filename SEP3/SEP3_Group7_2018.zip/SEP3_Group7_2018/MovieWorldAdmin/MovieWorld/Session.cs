﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieWorld
{
    public static class Session
    {
        public static bool IsSession { get; set; }

    }
}
