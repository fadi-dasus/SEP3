package sep.via.dk.sep3JPA.dao.ticket;

import sep.via.dk.sep3JPA.domain.Ticket;

public interface TicketDAO {
	void addTicket(Ticket ticket) ;

}
