﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieWorld
{
    public static class MovieList
    {
        public static List<Movie> movies = new List<Movie>();
       
    }
}
