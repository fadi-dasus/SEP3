﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieWorld
{
    class Ticket
    {
        public Movie movie { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string movieDate { get; set; }
        public string time { get; set; }
        public string dateOfBirth { get; set; }

    }
}
